<?php
/**
 * Created by PhpStorm.
 * User: juniair
 * Date: 2016-06-03
 * Time: 오후 9:50
 */
    if(isset($_SESSION['user_login'])) {
        
    }
        session_start();
?>