<?php
/**
 * Created by PhpStorm.
 * User: juniair
 * Date: 2016-06-01
 * Time: 오후 12:16
 */

?>
<!-- 재사용 부분 -->
<!-- Header -->
<header class="masthead">
    <div class="container">
        <a class="masthead-logo" href="./">
            <span class="mega-octicon">NGN Lab.</span>
        </a>
        <!-- Navigation -->
        <nav class="masthead-nav">
            <a href="./about/">About</a>
            <a href="./member/">Member</a>
            <a href="./notice/">Gallery & Courses</a>
            <a href="./signin/">Sign in</a>

        </nav>
        <!-- Navigation -->
    </div>
</header>
<!-- Header -->
<!-- 재사용 부분 -->
